import React from 'react'
import BreadCrumb from '../GlobelComponent/BreadCrumb'

const SingleProduct = () => {
  return (
    <>
      <BreadCrumb/>
    </>
  )
}

export default SingleProduct